const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password', // Or your real password if set
  database: 'student_feedback'
});

connection.connect((err) => {
  if (err) throw err;
  console.log("✅ MySQL connected");
});

module.exports = connection;
