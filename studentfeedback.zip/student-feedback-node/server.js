const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password', // your password if any
  database: 'feedback_system'
});

db.connect(err => {
  if (err) throw err;
  console.log('✅ MySQL connected');
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Insert feedback to DB
app.post('/submit', (req, res) => {
  const { name, email, feedback } = req.body;

  if (!name || !email || !feedback) {
    return res.status(400).send('All fields are required.');
  }

  const sql = 'INSERT INTO feedbacks (name, email, feedback) VALUES (?, ?, ?)';
  db.query(sql, [name, email, feedback], (err, result) => {
    if (err) return res.status(500).send('Database error.');
    console.log('✅ Feedback inserted');
    res.redirect('/thankyou.html');
  });
});

app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
